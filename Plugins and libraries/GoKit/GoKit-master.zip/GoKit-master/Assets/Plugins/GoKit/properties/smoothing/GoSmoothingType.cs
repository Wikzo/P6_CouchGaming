using UnityEngine;
using System.Collections;


public enum GoSmoothingType
{
	Lerp,
	Slerp
}
