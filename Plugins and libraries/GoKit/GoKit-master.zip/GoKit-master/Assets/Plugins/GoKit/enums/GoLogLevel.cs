using UnityEngine;
using System.Collections;


public enum GoLogLevel
{
	None,
	Info,
	Warn,
	Error
}
